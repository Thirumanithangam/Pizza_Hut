package demo;

public class MiniPath {

}
