package com.db.utils;

import java.sql.*;

public class DbConnection {

    public static Connection init() {
        Connection con = null;
        try {
            // Load the MySQL JDBC driver class
            Class.forName("com.mysql.jdbc.Driver");
            // Establish the database connection
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/pizza_shop_db", "root", "User12!@");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return con;
    }
}
